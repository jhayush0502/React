import React from 'react'
import loading from './progress.gif'
function Factorial(num)
{
var p=new Promise(function(resolve){
setTimeout(function(){
var i=1,j=1;
for(;j<=num;j++)
{
i=i*j;
}
resolve(i);
},4000);
});
return p;
}

const App=()=>{

const [factorial,setFactorial]=React.useState(0);
const [jobStarted,setJobStarted]=React.useState(false);
const [processing,setProcessing]=React.useState(false);

const buttonClickHandler=()=>{
setProcessing(true);
setJobStarted(true);
var prms=Factorial(5);
prms.then(function(factorial){
setFactorial(f);
setProcessing(false);
});
}

return(
<div>
<h1>Thinking Machines</h1>
<h3> Factorial calculator</h3>
<button type='button' onClick={buttonClickHandler}>Click Here</button>
<br/>
{ jobStarted===true && processing===true && <img src={loading} />}
{ jobStarted===true && processing===true && "Factorial : " }
{jobStarted===true && processing===true && factorial }
</div>
)
}
export default App;