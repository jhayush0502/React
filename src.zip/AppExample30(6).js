import React from 'react' ;
import {withStyles} from '@material-ui/core/styles';
import Paper from '@material-ui/core/Paper';
import Grid from '@material-ui/core/Grid';
import Chip from '@material-ui/core/Chip';
import Typography from '@material-ui/core/Typography';
import Hidden from '@material-ui/core/Typography';

const lookAndFeel=()=>{
return ({
mainContainer :{
margin : "10px",
border : "1px solid magenta",
flexGrow : 1,
padding :"10px"
},
paper :{padding : "5px",
color: "red"
}
})
}

const WrapperContainer=(props)=>{
return(
<Grid container {...props}/>
)
}

const ContainerItem=(props)=>{
return(
<Grid item {...props}/>
)
}

const App=withStyles(lookAndFeel)(({classes,justify})=>{
const occupyColumn=3;
return(
<div className={classes.mainContainer}>
<WrapperContainer spacing={4}>

<ContainerItem xs={12}>
<Paper className={classes.paper}>
<WrapperContainer justify="center">
<ContainerItem><Chip label='Some Heading'/></ContainerItem>
</WrapperContainer>
</Paper>
</ContainerItem>

<ContainerItem xs={occupyColumn}>
<Paper className={classes.paper}>
<WrapperContainer justify="center">
<ContainerItem><Chip label='4'/></ContainerItem>
<ContainerItem><Chip label='5'/></ContainerItem>
<ContainerItem><Chip label='6'/></ContainerItem>
</WrapperContainer>
</Paper>
</ContainerItem>

<ContainerItem xs={occupyColumn}>
<Paper className={classes.paper}>
<WrapperContainer justify="space-around">
<ContainerItem><Chip label='7'/></ContainerItem>
<ContainerItem><Chip label='8'/></ContainerItem>
<ContainerItem><Chip label='9'/></ContainerItem>
</WrapperContainer>
</Paper>
</ContainerItem>

<ContainerItem xs={occupyColumn}>
<Paper className={classes.paper}>
<WrapperContainer justify="space-evenly">
<ContainerItem><Chip label='10'/></ContainerItem>
<ContainerItem><Chip label='A'/></ContainerItem>
<ContainerItem><Chip label='11'/></ContainerItem>
</WrapperContainer>
</Paper>
</ContainerItem>


<ContainerItem xs={occupyColumn}>
<Paper className={classes.paper}>
<WrapperContainer justify={justify}>
<ContainerItem><Chip label='1'/></ContainerItem>
<ContainerItem><Chip label='2'/></ContainerItem>
<ContainerItem><Chip label='3'/></ContainerItem>
</WrapperContainer>
</Paper>
</ContainerItem>

<ContainerItem xs={occupyColumn}>
<Paper className={classes.paper}>
<WrapperContainer justify="center">
<ContainerItem><Chip label='4'/></ContainerItem>
<ContainerItem><Chip label='5'/></ContainerItem>
<ContainerItem><Chip label='6'/></ContainerItem>
</WrapperContainer>
</Paper>
</ContainerItem>

<ContainerItem xs={occupyColumn}>
<Paper className={classes.paper}>
<WrapperContainer justify="space-around">
<ContainerItem><Chip label='7'/></ContainerItem>
<ContainerItem><Chip label='8'/></ContainerItem>
<ContainerItem><Chip label='9'/></ContainerItem>
</WrapperContainer>
</Paper>
</ContainerItem>

<ContainerItem xs={occupyColumn}>
<Paper className={classes.paper}>
<WrapperContainer justify="space-evenly">
<ContainerItem><Chip label='10'/></ContainerItem>
<ContainerItem><Chip label='A'/></ContainerItem>
<ContainerItem><Chip label='11'/></ContainerItem>
</WrapperContainer>
</Paper>
</ContainerItem>


<ContainerItem xs={occupyColumn}>
<Paper className={classes.paper}>
<WrapperContainer justify={justify}>
<ContainerItem><Chip label='1'/></ContainerItem>
<ContainerItem><Chip label='2'/></ContainerItem>
<ContainerItem><Chip label='3'/></ContainerItem>
</WrapperContainer>
</Paper>
</ContainerItem>

<ContainerItem xs={occupyColumn}>
<Paper className={classes.paper}>
<WrapperContainer justify="center">
<ContainerItem><Chip label='4'/></ContainerItem>
<ContainerItem><Chip label='5'/></ContainerItem>
<ContainerItem><Chip label='6'/></ContainerItem>
</WrapperContainer>
</Paper>
</ContainerItem>

<ContainerItem xs={occupyColumn}>
<Paper className={classes.paper}>
<WrapperContainer justify="space-around">
<ContainerItem><Chip label='7'/></ContainerItem>
<ContainerItem><Chip label='8'/></ContainerItem>
<ContainerItem><Chip label='9'/></ContainerItem>
</WrapperContainer>
</Paper>
</ContainerItem>

<ContainerItem xs={occupyColumn}>
<Paper className={classes.paper}>
<WrapperContainer justify="space-evenly">
<ContainerItem><Chip label='10'/></ContainerItem>
<ContainerItem><Chip label='A'/></ContainerItem>
<ContainerItem><Chip label='11'/></ContainerItem>
</WrapperContainer>
</Paper>
</ContainerItem>

<ContainerItem xs={occupyColumn}>
<Paper className={classes.paper}>
<WrapperContainer justify={justify}>
<ContainerItem><Chip label='1'/></ContainerItem>
<ContainerItem><Chip label='2'/></ContainerItem>
<ContainerItem><Chip label='3'/></ContainerItem>
</WrapperContainer>
</Paper>
</ContainerItem>

<ContainerItem xs={occupyColumn}>
<Paper className={classes.paper}>
<WrapperContainer justify="center">
<ContainerItem><Chip label='4'/></ContainerItem>
<ContainerItem><Chip label='5'/></ContainerItem>
<ContainerItem><Chip label='6'/></ContainerItem>
</WrapperContainer>
</Paper>
</ContainerItem>

<ContainerItem xs={occupyColumn}>
<Paper className={classes.paper}>
<WrapperContainer justify="space-around">
<ContainerItem><Chip label='7'/></ContainerItem>
<ContainerItem><Chip label='8'/></ContainerItem>
<ContainerItem><Chip label='9'/></ContainerItem>
</WrapperContainer>
</Paper>
</ContainerItem>

<ContainerItem xs={occupyColumn}>
<Paper className={classes.paper}>
<WrapperContainer justify="space-evenly">
<ContainerItem><Chip label='10'/></ContainerItem>
<ContainerItem><Chip label='A'/></ContainerItem>
<ContainerItem><Chip label='11'/></ContainerItem>
</WrapperContainer>
</Paper>
</ContainerItem>

<ContainerItem xs={occupyColumn}>
<Paper className={classes.paper}>
<WrapperContainer justify={justify}>
<ContainerItem><Chip label='1'/></ContainerItem>
<ContainerItem><Chip label='2'/></ContainerItem>
<ContainerItem><Chip label='3'/></ContainerItem>
</WrapperContainer>
</Paper>
</ContainerItem>

<ContainerItem xs={occupyColumn}>
<Paper className={classes.paper}>
<WrapperContainer justify="center">
<ContainerItem><Chip label='4'/></ContainerItem>
<ContainerItem><Chip label='5'/></ContainerItem>
<ContainerItem><Chip label='6'/></ContainerItem>
</WrapperContainer>
</Paper>
</ContainerItem>

<ContainerItem xs={occupyColumn}>
<Paper className={classes.paper}>
<WrapperContainer justify="space-around">
<ContainerItem><Chip label='7'/></ContainerItem>
<ContainerItem><Chip label='8'/></ContainerItem>
<ContainerItem><Chip label='9'/></ContainerItem>
</WrapperContainer>
</Paper>
</ContainerItem>

<ContainerItem xs={occupyColumn}>
<Paper className={classes.paper}>
<WrapperContainer justify="space-evenly">
<ContainerItem><Chip label='10'/></ContainerItem>
<ContainerItem><Chip label='A'/></ContainerItem>
<ContainerItem><Chip label='11'/></ContainerItem>
</WrapperContainer>
</Paper>
</ContainerItem>

<ContainerItem xs={occupyColumn}>
<Paper className={classes.paper}>
<WrapperContainer justify={justify}>
<ContainerItem><Chip label='1'/></ContainerItem>
<ContainerItem><Chip label='2'/></ContainerItem>
<ContainerItem><Chip label='3'/></ContainerItem>
</WrapperContainer>
</Paper>
</ContainerItem>

<ContainerItem xs={occupyColumn}>
<Paper className={classes.paper}>
<WrapperContainer justify="center">
<ContainerItem><Chip label='4'/></ContainerItem>
<ContainerItem><Chip label='5'/></ContainerItem>
<ContainerItem><Chip label='6'/></ContainerItem>
</WrapperContainer>
</Paper>
</ContainerItem>

<ContainerItem xs={occupyColumn}>
<Paper className={classes.paper}>
<WrapperContainer justify="space-around">
<ContainerItem><Chip label='7'/></ContainerItem>
<ContainerItem><Chip label='8'/></ContainerItem>
<ContainerItem><Chip label='9'/></ContainerItem>
</WrapperContainer>
</Paper>
</ContainerItem>

<ContainerItem xs={occupyColumn}>
<Paper className={classes.paper}>
<WrapperContainer justify="space-evenly">
<ContainerItem><Chip label='10'/></ContainerItem>
<ContainerItem><Chip label='A'/></ContainerItem>
<ContainerItem><Chip label='11'/></ContainerItem>
</WrapperContainer>
</Paper>
</ContainerItem>

<ContainerItem xs={occupyColumn}>
<Paper className={classes.paper}>
<WrapperContainer justify={justify}>
<ContainerItem><Chip label='1'/></ContainerItem>
<ContainerItem><Chip label='2'/></ContainerItem>
<ContainerItem><Chip label='3'/></ContainerItem>
</WrapperContainer>
</Paper>
</ContainerItem>

<ContainerItem xs={occupyColumn}>
<Paper className={classes.paper}>
<WrapperContainer justify="center">
<ContainerItem><Chip label='4'/></ContainerItem>
<ContainerItem><Chip label='5'/></ContainerItem>
<ContainerItem><Chip label='6'/></ContainerItem>
</WrapperContainer>
</Paper>
</ContainerItem>

<ContainerItem xs={occupyColumn}>
<Paper className={classes.paper}>
<WrapperContainer justify="space-around">
<ContainerItem><Chip label='7'/></ContainerItem>
<ContainerItem><Chip label='8'/></ContainerItem>
<ContainerItem><Chip label='9'/></ContainerItem>
</WrapperContainer>
</Paper>
</ContainerItem>

<ContainerItem xs={occupyColumn}>
<Paper className={classes.paper}>
<WrapperContainer justify="space-evenly">
<ContainerItem><Chip label='10'/></ContainerItem>
<ContainerItem><Chip label='A'/></ContainerItem>
<ContainerItem><Chip label='11'/></ContainerItem>
</WrapperContainer>
</Paper>
</ContainerItem>

<ContainerItem xs={occupyColumn}>
<Paper className={classes.paper}>
<WrapperContainer justify={justify}>
<ContainerItem><Chip label='1'/></ContainerItem>
<ContainerItem><Chip label='2'/></ContainerItem>
<ContainerItem><Chip label='3'/></ContainerItem>
</WrapperContainer>
</Paper>
</ContainerItem>

<ContainerItem xs={occupyColumn}>
<Paper className={classes.paper}>
<WrapperContainer justify="center">
<ContainerItem><Chip label='4'/></ContainerItem>
<ContainerItem><Chip label='5'/></ContainerItem>
<ContainerItem><Chip label='6'/></ContainerItem>
</WrapperContainer>
</Paper>
</ContainerItem>

<ContainerItem xs={occupyColumn}>
<Paper className={classes.paper}>
<WrapperContainer justify="space-around">
<ContainerItem><Chip label='7'/></ContainerItem>
<ContainerItem><Chip label='8'/></ContainerItem>
<ContainerItem><Chip label='9'/></ContainerItem>
</WrapperContainer>
</Paper>
</ContainerItem>

<ContainerItem xs={occupyColumn}>
<Paper className={classes.paper}>
<WrapperContainer justify="space-evenly">
<ContainerItem><Chip label='10'/></ContainerItem>
<ContainerItem><Chip label='A'/></ContainerItem>
<ContainerItem><Chip label='11'/></ContainerItem>
</WrapperContainer>
</Paper>
</ContainerItem>

<ContainerItem xs={occupyColumn}>
<Paper className={classes.paper}>
<WrapperContainer justify={justify}>
<ContainerItem><Chip label='1'/></ContainerItem>
<ContainerItem><Chip label='2'/></ContainerItem>
<ContainerItem><Chip label='3'/></ContainerItem>
</WrapperContainer>
</Paper>
</ContainerItem>

<ContainerItem xs={occupyColumn}>
<Paper className={classes.paper}>
<WrapperContainer justify="center">
<ContainerItem><Chip label='4'/></ContainerItem>
<ContainerItem><Chip label='5'/></ContainerItem>
<ContainerItem><Chip label='6'/></ContainerItem>
</WrapperContainer>
</Paper>
</ContainerItem>

<ContainerItem xs={occupyColumn}>
<Paper className={classes.paper}>
<WrapperContainer justify="space-around">
<ContainerItem><Chip label='7'/></ContainerItem>
<ContainerItem><Chip label='8'/></ContainerItem>
<ContainerItem><Chip label='9'/></ContainerItem>
</WrapperContainer>
</Paper>
</ContainerItem>

<ContainerItem xs={occupyColumn}>
<Paper className={classes.paper}>
<WrapperContainer justify="space-evenly">
<ContainerItem><Chip label='10'/></ContainerItem>
<ContainerItem><Chip label='A'/></ContainerItem>
<ContainerItem><Chip label='11'/></ContainerItem>
</WrapperContainer>
</Paper>
</ContainerItem>

<ContainerItem xs={occupyColumn}>
<Paper className={classes.paper}>
<WrapperContainer justify={justify}>
<ContainerItem><Chip label='1'/></ContainerItem>
<ContainerItem><Chip label='2'/></ContainerItem>
<ContainerItem><Chip label='3'/></ContainerItem>
</WrapperContainer>
</Paper>
</ContainerItem>

<ContainerItem xs={occupyColumn}>
<Paper className={classes.paper}>
<WrapperContainer justify="center">
<ContainerItem><Chip label='4'/></ContainerItem>
<ContainerItem><Chip label='5'/></ContainerItem>
<ContainerItem><Chip label='6'/></ContainerItem>
</WrapperContainer>
</Paper>
</ContainerItem>

<ContainerItem xs={occupyColumn}>
<Paper className={classes.paper}>
<WrapperContainer justify="space-around">
<ContainerItem><Chip label='7'/></ContainerItem>
<ContainerItem><Chip label='8'/></ContainerItem>
<ContainerItem><Chip label='9'/></ContainerItem>
</WrapperContainer>
</Paper>
</ContainerItem>

<ContainerItem xs={occupyColumn}>
<Paper className={classes.paper}>
<WrapperContainer justify="space-evenly">
<ContainerItem><Chip label='10'/></ContainerItem>
<ContainerItem><Chip label='A'/></ContainerItem>
<ContainerItem><Chip label='11'/></ContainerItem>
</WrapperContainer>
</Paper>
</ContainerItem>

<ContainerItem xs={occupyColumn}>
<Paper className={classes.paper}>
<WrapperContainer justify={justify}>
<ContainerItem><Chip label='1'/></ContainerItem>
<ContainerItem><Chip label='2'/></ContainerItem>
<ContainerItem><Chip label='3'/></ContainerItem>
</WrapperContainer>
</Paper>
</ContainerItem>

<ContainerItem xs={occupyColumn}>
<Paper className={classes.paper}>
<WrapperContainer justify="center">
<ContainerItem><Chip label='4'/></ContainerItem>
<ContainerItem><Chip label='5'/></ContainerItem>
<ContainerItem><Chip label='6'/></ContainerItem>
</WrapperContainer>
</Paper>
</ContainerItem>

<ContainerItem xs={occupyColumn}>
<Paper className={classes.paper}>
<WrapperContainer justify="space-around">
<ContainerItem><Chip label='7'/></ContainerItem>
<ContainerItem><Chip label='8'/></ContainerItem>
<ContainerItem><Chip label='9'/></ContainerItem>
</WrapperContainer>
</Paper>
</ContainerItem>

<ContainerItem xs={occupyColumn}>
<Paper className={classes.paper}>
<WrapperContainer justify="space-evenly">
<ContainerItem><Chip label='10'/></ContainerItem>
<ContainerItem><Chip label='A'/></ContainerItem>
<ContainerItem><Chip label='11'/></ContainerItem>
</WrapperContainer>
</Paper>
</ContainerItem>

<ContainerItem xs={occupyColumn}>
<Paper className={classes.paper}>
<WrapperContainer justify={justify}>
<ContainerItem><Chip label='1'/></ContainerItem>
<ContainerItem><Chip label='2'/></ContainerItem>
<ContainerItem><Chip label='3'/></ContainerItem>
</WrapperContainer>
</Paper>
</ContainerItem>

<ContainerItem xs={occupyColumn}>
<Paper className={classes.paper}>
<WrapperContainer justify="center">
<ContainerItem><Chip label='4'/></ContainerItem>
<ContainerItem><Chip label='5'/></ContainerItem>
<ContainerItem><Chip label='6'/></ContainerItem>
</WrapperContainer>
</Paper>
</ContainerItem>

<ContainerItem xs={occupyColumn}>
<Paper className={classes.paper}>
<WrapperContainer justify="space-around">
<ContainerItem><Chip label='7'/></ContainerItem>
<ContainerItem><Chip label='8'/></ContainerItem>
<ContainerItem><Chip label='9'/></ContainerItem>
</WrapperContainer>
</Paper>
</ContainerItem>

<ContainerItem xs={occupyColumn}>
<Paper className={classes.paper}>
<WrapperContainer justify="space-evenly">
<ContainerItem><Chip label='10'/></ContainerItem>
<ContainerItem><Chip label='A'/></ContainerItem>
<ContainerItem><Chip label='11'/></ContainerItem>
</WrapperContainer>
</Paper>
</ContainerItem>

<ContainerItem xs={occupyColumn}>
<Paper className={classes.paper}>
<WrapperContainer justify={justify}>
<ContainerItem><Chip label='1'/></ContainerItem>
<ContainerItem><Chip label='2'/></ContainerItem>
<ContainerItem><Chip label='3'/></ContainerItem>
</WrapperContainer>
</Paper>
</ContainerItem>

<ContainerItem xs={occupyColumn}>
<Paper className={classes.paper}>
<WrapperContainer justify="center">
<ContainerItem><Chip label='4'/></ContainerItem>
<ContainerItem><Chip label='5'/></ContainerItem>
<ContainerItem><Chip label='6'/></ContainerItem>
</WrapperContainer>
</Paper>
</ContainerItem>

<ContainerItem xs={occupyColumn}>
<Paper className={classes.paper}>
<WrapperContainer justify="space-around">
<ContainerItem><Chip label='7'/></ContainerItem>
<ContainerItem><Chip label='8'/></ContainerItem>
<ContainerItem><Chip label='9'/></ContainerItem>
</WrapperContainer>
</Paper>
</ContainerItem>

<ContainerItem xs={occupyColumn}>
<Paper className={classes.paper}>
<WrapperContainer justify="space-evenly">
<ContainerItem><Chip label='10'/></ContainerItem>
<ContainerItem><Chip label='A'/></ContainerItem>
<ContainerItem><Chip label='11'/></ContainerItem>
</WrapperContainer>
</Paper>
</ContainerItem>

<ContainerItem xs={occupyColumn}>
<Paper className={classes.paper}>
<WrapperContainer justify={justify}>
<ContainerItem><Chip label='1'/></ContainerItem>
<ContainerItem><Chip label='2'/></ContainerItem>
<ContainerItem><Chip label='3'/></ContainerItem>
</WrapperContainer>
</Paper>
</ContainerItem>

<ContainerItem xs={occupyColumn}>
<Paper className={classes.paper}>
<WrapperContainer justify="center">
<ContainerItem><Chip label='4'/></ContainerItem>
<ContainerItem><Chip label='5'/></ContainerItem>
<ContainerItem><Chip label='6'/></ContainerItem>
</WrapperContainer>
</Paper>
</ContainerItem>

<ContainerItem xs={occupyColumn}>
<Paper className={classes.paper}>
<WrapperContainer justify="space-around">
<ContainerItem><Chip label='7'/></ContainerItem>
<ContainerItem><Chip label='8'/></ContainerItem>
<ContainerItem><Chip label='9'/></ContainerItem>
</WrapperContainer>
</Paper>
</ContainerItem>

<ContainerItem xs={occupyColumn}>
<Paper className={classes.paper}>
<WrapperContainer justify="space-evenly">
<ContainerItem><Chip label='10'/></ContainerItem>
<ContainerItem><Chip label='A'/></ContainerItem>
<ContainerItem><Chip label='11'/></ContainerItem>
</WrapperContainer>
</Paper>
</ContainerItem>


<ContainerItem xs={6}>
<WrapperContainer justify="flex-end">
<ContainerItem><Typography>&copy; 2021</Typography></ContainerItem>
</WrapperContainer>
</ContainerItem>

<ContainerItem xs={6}>
<WrapperContainer justify="flex-start">
<ContainerItem>Ayush jha</ContainerItem>
</WrapperContainer>
</ContainerItem>

</WrapperContainer>
</div>
)
});
export default App;
