import React from 'react';

const App=()=>{

const [title,setTitle]=React.useState("Thinking Machines");
const [year,setYear]=React.useState(2021);

const students=[
{"id":101,"name":"Prakruti jain","type":"Full time","company":"Grow","package":"20 LPA"},
{"id":102,"name":"Shreyash sharma","type":"Full time","company":"Amazon","package":"18 LPA"},
{"id":103,"name":"Siddhant Johari","type":"Full time","company":"Accolite","package":"10 LPA"},
{"id":104,"name":"Yash Govindani","type":"Internship","company":"InvesTrack","package":"15000 per month"},
{"id":105,"name":"Aman sharma","type":"Internship","company":"Iprep","package":"21500 per month "}
];

const [searchWhat,setSearchCriteria]=React.useState("None");
const applyFilter=(ev)=>{
if(ev.currentTarget.value.length<3)
{
setSearchCriteria("None");
return ;
}
setSearchCriteria(ev.currentTarget.value);
}

const filteredStudents=students.filter((student)=>{
if(searchWhat==="None") return true;
return student.company.toLowerCase().includes(searchWhat.toLowerCase());
});

return (
<div>
<TitleComponent title={title} palcementYear={year}/>
<SearchBox onSearch={applyFilter}/>
Filter applied : {searchWhat}
<StudentList students={filteredStudents}/>
</div>
)
}

const TitleComponent=(props)=>{

return(
<h1>{props.title}-placements {props.placementYear}</h1>
)
}


const SearchBox=(props)=>{
const searchIt=(ev)=>{
props.onSearch(ev);
}
return(
<div>
<lable htmlFor="searchBox">Search : </lable>
<input type='text' id='searchBox' onChange={searchIt} />
</div>
)
}

const StudentList=(props)=>{
return(
<ul>
{
props.students.map((student)=>{
return(
<li key={student.id}>{student.name}({student.company})</li>
)
})
}
</ul>
)
}
export default App;

