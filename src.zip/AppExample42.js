import React from 'react';
import FormGroup from '@material-ui/core/FormGroup';
import FormLabel from '@material-ui/core/FormLabel';
import OutlinedInput from '@material-ui/core/OutlinedInput';
import FilledInput from '@material-ui/core/FilledInput';
import Select from '@material-ui/core/Select';
import MenuItem from '@material-ui/core/MenuItem';
import InputAdornment from '@material-ui/core/InputAdornment';
import Checkbox from '@material-ui/core/Checkbox';
import Radio from '@material-ui/core/Radio';
import RadioGroup from '@material-ui/core/RadioGroup';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import SearchIcon from '@material-ui/icons/Search';
import Switch from '@material-ui/core/Switch';
import Button from '@material-ui/core/Button';

const AppExample42=()=>{
const searchEducation=()=>{
alert('Searching Education');
}
const saveForm=()=>{
alert('Save');
}
return(
<>
<h1>Thinking Machines</h1>
<FormGroup>
<FormLabel>First name</FormLabel>
<OutlinedInput placeholder="Enter first name" />
</FormGroup>

<FormGroup>
<FormLabel>Last name</FormLabel>
<FilledInput placeholder="Enter last name"/>
</FormGroup>

<FormGroup>
<FormLabel>Address</FormLabel>
<OutlinedInput multiline={true} rows={5}/>
</FormGroup>

<FormGroup>
<FormLabel>City</FormLabel>
<Select defaultValue={102}>
<MenuItem value={101}>Ujjain</MenuItem>
<MenuItem value={102}>Indore</MenuItem>
<MenuItem value={103}>Bhopal</MenuItem>
</Select>
</FormGroup>

<FormGroup>
<FormLabel>Education</FormLabel>
<OutlinedInput placeholder='Education'
endAdornment={<InputAdornment position='end'>
<SearchIcon onClick={searchEducation}/>
</InputAdornment>}
/>
</FormGroup>

<FormGroup>
<FormLabel>Date of birth</FormLabel>
<OutlinedInput type='date' />
</FormGroup>

<FormGroup>
<FormLabel>Time of Birth</FormLabel>
<OutlinedInput type='time' />
</FormGroup>

<FormGroup>
<FormLabel>Started working from which month</FormLabel>
<OutlinedInput type='month'/>
</FormGroup>

<FormGroup>
<FormLabel>Left last Job in the week</FormLabel>
<OutlinedInput type='week'/>
</FormGroup>

<FormGroup>
<FormLabel>Previous Salary</FormLabel>
<OutlinedInput type='number' inputProps={{min:10000,max:300000}}/>
</FormGroup>

<FormGroup>
<FormLabel>Password</FormLabel>
<OutlinedInput type='password' />
</FormGroup>

<FormGroup>
<FormLabel>Select Profile Picture</FormLabel>
<OutlinedInput type='file'/>
</FormGroup>

<FormGroup>
<FormLabel>IsIndian</FormLabel>
<Checkbox/>
</FormGroup>

<FormControlLabel
label='Likes to teach'
value='Y'
labelPlacement='end'
control={<Checkbox />}
/>

<FormGroup>
<FormLabel>Gender</FormLabel>
<RadioGroup>
<FormControlLabel
label='Male'
labelPlacement='end'
value='M'
control={<Radio />}
/>
<FormControlLabel
label='Female'
labelPlacement='end'
value='F'
control={<Radio/>}
/>
</RadioGroup>
</FormGroup>

<FormGroup>
<FormLabel>Send promotional mail</FormLabel>
<Switch />
</FormGroup>

<Button onClick={saveForm} varient='contained'>Save</Button>

</>
);
}
export default AppExample42;