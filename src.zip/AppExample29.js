import React from 'react'
import { withStyles } from '@material-ui/core/styles'

const lookAndFeelClassGenerator=()=>{
return({
"mainContainer" : {
width : "400px",
height : "300px",
border : "1px solid red",
margin : "10px",
padding : "10px"
},
"mainHeading" :{
fontSize : "30pt",
color : "orange",
fontWeight : "bold"
},
"subHeading" :{
fontSize : "20pt",
color : "magenta",
fontWeight : "bold"
}
})
};

const App=withStyles(lookAndFeelClassGenerator)(({classes})=>{
return (
<div className={classes.mainContainer}>
<div className={classes.mainHeading}>Thinking Machines</div>
<div className={classes.subHeading}>Think Big</div>
<SloganComponent />
</div>
)
});

const SloganComponent=({heading})=>{
alert(heading);
if(heading) return(
<h3>We Teach More than we promise to teach</h3>
)
else return(
<div>We Teach More than we promise to teach</div>
)
}
export default App;