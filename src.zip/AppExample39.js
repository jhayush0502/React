import React from 'react';
import {withStyles} from '@material-ui/core';
import Accordion from '@material-ui/core/Accordion';
import AccordionSummary from '@material-ui/core/AccordionSummary';
import AccordionDetails from '@material-ui/core/AccordionDetails';
import Typography from '@material-ui/core/Typography';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';

const myStyles=(theme)=>{
return({
mainContainer :{
flexGrow : 1
}
})}

const AppExample39=(props)=>{
const onAccordionStateChange=(idx,isExpanded)=>{
alert(idx+","+isExpanded);
}


return(
<div className={props.classes.mainContainer}>
<Accordion key={0} disable={false}onChange={(ev,ex)=>{onAccordionStateChange(0,ex);}}>
<AccordionSummary expandIcon={<ExpandMoreIcon/>}>
<Typography>Courses</Typography>
</AccordionSummary>
<AccordionDetails>
<Typography>
C<br/>
C++<br/>
Java<br/>
J2EE<br/>
Python<br/>
Node JS<br/>
ML<br/>
IOT<br/>
Flutter<br/>
</Typography>
</AccordionDetails>
</Accordion>


<Accordion key={1} disable={false}  onChange={(ev,ex)=>{onAccordionStateChange(1,ex);}}>
<AccordionSummary expandIcon={<ExpandMoreIcon/>}>
<Typography>Contact Us</Typography>
</AccordionSummary>
<AccordionDetails>
<Typography>
Ayush Jha<br/>
Full Stack Web Developer<br/>
9522226242<br/>
</Typography>
</AccordionDetails>
</Accordion>

</div>
);

}
export default withStyles(myStyles)(AppExample39)