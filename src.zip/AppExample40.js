import React from 'react'
import {makeStyles} from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import TableHead from '@material-ui/core/TableHead';
import TableBody from '@material-ui/core/TableBody';
import TableRow from '@material-ui/core/TableRow';
import TableCell from '@material-ui/core/TableCell';
import CircularProgress from '@material-ui/core/CircularProgress';

const myStyles=makeStyles((theme)=>{
return({
mainContainer:{flexGrow : 1},
content:{
padding: "10px",
textAling:"center"
},
mainHeading:{
fontSize:"24pt",
fontWeight:"bold",
color:"#2222ab"
},
})
});

const getStudents=()=>{
var promise=new Promise((resolve)=>{
var students=[
{"name":"Aditi","company":"HashedIn","package":"8LPA"},
{"name":"Suthy","company":"Intel","package":"15LPA"},
{"name":"Rutea","company":"Rizi","package":"12LPA"},
];
setTimeout(()=>{
resolve(students);
},5000);
});
return promise;
}

const AppExample40=()=>{
const styleClasses=myStyles();
const [students,setStudents]=React.useState([]);
const [showProgress,setShowProgress]=React.useState(true);

React.useEffect(()=>{
getStudents().then((s)=>{
setShowProgress(false);
setStudents(s);
});
},[]);

return(
<div className={styleClasses.mainContainer}>
<div className={styleClasses.mainHeading}>Thinking Machines</div>
<div className={styleClasses.content}>
<Table>
<TableHead>
<TableRow>
<TableCell aling='right'>S.No.</TableCell>
<TableCell>Student</TableCell>
<TableCell>Company</TableCell>
<TableCell>Package</TableCell>
</TableRow>
</TableHead>
<TableBody>
{students.map((student,idx)=>{
return(
<TableRow>
<TableCell aling='right'>{idx+1}</TableCell>
<TableCell>{student.name}</TableCell>
<TableCell>{student.company}</TableCell>
<TableCell>{student.package}</TableCell>
</TableRow>
);
})}
</TableBody>
</Table><br/><br/>

<CircularProgress />
</div>
</div>
);
};
export default AppExample40;