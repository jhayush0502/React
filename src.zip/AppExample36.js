import React from 'react';
import {BrowserRouter,Route,Link} from 'react-router-dom';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import Menu from '@material-ui/core/Menu';
import MenuItem from '@material-ui/core/MenuItem';
import {withStyles} from '@material-ui/core';
import IconButton from '@material-ui/core/IconButton';
import Grid from '@material-ui/core/Grid';
import MenuIcon from '@material-ui/icons/Menu';
import Typography from '@material-ui/core/Typography';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemText from '@material-ui/core/ListItemText';
import Divider from '@material-ui/core/Divider';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import AddBox from '@material-ui/icons/AddBox';
import Drawer from '@material-ui/core/Drawer';

const myStyles=(theme)=>{
return({
"mainContainer" :
{
flexGrow : 1
},
appBarSpacer :  theme.mixins.toolbar
,
welcome:{
fontSize : "24pt",
fontWeight :"bold",
color : "#2929aa"
} 
});   
}

const AppExample36=withStyles(myStyles)(({classes})=>{
return(
<BrowserRouter>
<Route exact path='/' component={HomeComponent} />
<Route exact path='/Courses' component={CoursesComponent} />
<Route exact path='/ContactUs' component={ContactComponent} />
</BrowserRouter>
)
});

const AppBarComponent=withStyles(myStyles)((props)=>{
const [menuAnchor,setMenuAnchor]=React.useState(null);
var front;
if(props.one==='')
{
front='Home';
}
else
{
front=props.one;
}
const showMenu=(ev)=>{
setMenuAnchor(ev.currentTarget);
}
const hideMenu=()=>{
setMenuAnchor(null);
}


const[showDrawer,setShowDrawer]=React.useState(false);
const openDrawer=()=>{
setShowDrawer(true);
}
const closeDrawer=()=>{
setShowDrawer(false);
}



return(
<div>
<AppBar>
<Toolbar>
<IconButton color='inherit' onClick={showMenu}><MenuIcon/></IconButton>
<Typography >Ayush Jha    --    {props.heading}</Typography>
<Menu
keepMounted
anchorEl={menuAnchor}
open={Boolean(menuAnchor)}
onClose={hideMenu}
>
<Drawer
open={showDrawer}
variant="persistent"
onClose={closeDrawer}
>
<MenuItem component={Link} to={'/'+props.one}>{front}</MenuItem>
<MenuItem component={Link} to={'/'+props.two}>{props.two}</MenuItem>
</Drawer>
</Menu>
</Toolbar>
</AppBar>
</div>
);
});

const HomeComponent=withStyles(myStyles)(({classes})=>{
return(
<div>
<AppBarComponent heading='Home' one='Courses' two='ContactUs'/>
<div className={classes.appBarSpacer} />
<Grid container justify='center'>
<Grid item xs={1}><div className={classes.welcome}>Welcome</div></Grid>
</Grid>
</div>
);
});

const CoursesComponent=withStyles(myStyles)(({classes})=>{
return(
<div>
<AppBarComponent heading='Courses' one='' two='ContactUs'/>
<div className={classes.appBarSpacer} />
<h3>Courses</h3>
</div>
);
});

const ContactComponent=withStyles(myStyles)(({classes})=>{
return(
<div>
<AppBarComponent heading='Contact Us' one='' two='Courses'/>
<div className={classes.appBarSpacer} />
<h3>Contact Us</h3>
</div>
);
});

export default AppExample36;