function whatever()
{
alert("Whatever");
}
export default whatever