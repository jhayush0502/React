import React from 'react';
import {BrowserRouter,Route,Link} from 'react-router-dom';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import Menu from '@material-ui/core/Menu';
import MenuItem from '@material-ui/core/MenuItem';
import {withStyles} from '@material-ui/core';
import IconButton from '@material-ui/core/IconButton';
import Grid from '@material-ui/core/Grid';
import MenuIcon from '@material-ui/icons/Menu';
import Typography from '@material-ui/core/Typography';

const myStyles=()=>{
return({
"mainContainer" :
{
flexGrow : 1
},
appBarSpacer : {
marginTop :"100px"
},
welcome:{
fontSize : "24pt",
fontWeight :"bold",
color : "#2929aa"
} 
});   
}

const App=withStyles(myStyles)(({classes})=>{
return(
<BrowserRouter>
<Route exact path='/' component={HomeComponent} />
<Route exact path='/courses' component={CoursesComponent} />
<Route exact path='/contactUs' component={ContactComponent} />
</BrowserRouter>
)
});

const HomeComponent=withStyles(myStyles)(({classes})=>{
const [menuAnchor,setMenuAnchor]=React.useState(null);
const showMenu=(ev)=>{
setMenuAnchor(ev.currentTarget);
}
const hideMenu=()=>{
setMenuAnchor(null);
}

return(
<div>
<AppBar>
<Toolbar>
<IconButton color='inherit' onClick={showMenu}><MenuIcon/></IconButton>
</Toolbar>
<Menu
keepMounted
anchorEl={menuAnchor}
open={Boolean(menuAnchor)}
onClose={hideMenu}
>
<MenuItem component={Link} to='/courses'>Courses</MenuItem>
<MenuItem component={Link} to='/contactUs'>Contact Us </MenuItem>
</Menu>
</AppBar>
<div className={classes.appBarSpacer} />
<Grid container justify='center'>
<Grid item xs={1}><div className={classes.welcome}>Welcome</div></Grid>
</Grid>
</div>
);
});

const CoursesComponent=()=>{
return(
<div>
<h1>Thinking Machines</h1>
<h3>Courses</h3>
<Link to='/'>Home</Link>
</div>
);
}

const ContactComponent=()=>{
return(
<div>
<h1>Thinking Machines</h1>
<h3>Contact Us</h3>
<Link to='/'>Home</Link>
</div>
);
}

export default App;