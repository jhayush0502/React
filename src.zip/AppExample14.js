import React from 'react'

const getPlacements=()=>{
const promise=new Promise((resolve)=>{
fetch("/placements").then((response)=>{
return response.json();
}).then((employees)=>{resolve(employees);});
});
return promise;
}

const App=()=>{

const [employees,setEmployeess]=React.useState([]);

React.useEffect(()=>{
const promise=getPlacements();
promise.then((emps)=>{
//alert(emps);
//alert(JSON.stringify(emps));
setEmployees(emps);
});
},[]);

const changeTitle=()=>{
setTitle("Good Employees");
}

return(
<div>
<TitleComponent title={title} />
<h1>Thinking Machines</h1>
<button type='button' onClick={changeTitle}>Change Title</button>
<EmployeeListComponent employees={employees}/>
</div>
)
}

const EmployeeListComponent=({employees})=>{
return(
<ul>
employees.map((employee)=>{
return (
<li key={employee.id}>{employee.firstName} {employee.lastName}</li>
)
})
</ul>
}

const TitleComponent=({title})=>{
return(
<div>
<h3>{title}</h3>
</div>
)
}

export default App;