import React from 'react';
import Cartoon,{Great,ThinkingMachines} from './abcd';
import {Slogan as TMSlogan} from './abcd';
import {default as WW} from './pqr';

const AppExample27=()=>{

const doSomething=()=>{
WW();
Cartoon();
Great();
alert(TMSlogan);
alert(ThinkingMachines);
}

return(
<div>
<h1>Thinking Machines</h1>
<button onClick={doSomething} type='Button' >Click Me</button>
</div>
)
}
export default AppExample27;