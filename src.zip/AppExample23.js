import React from 'react';
import lookAndFeel from "./AppExample23.module.css"
const App=()=>{
const [themeName,setThemeName]=React.useState("darkLook");
const [theme,setTheme]=React.useState(lookAndFeel.darkLook);

const changeTheme=(ev)=>{
setTheme(ev.target.value);
if(ev.target.value=="darkLook")
{
setTheme(lookAndFeel.darkLook);
}
if(ev.target.value=="lightLook")
{
setTheme(lookAndFeel.lightLook);
}
}

return(
<div className={lookAndFeel.mainContainer}>
<h1>Thinking Machines</h1>
Select theme &nbsp;&nbsp;
<select value={themeName} onChange={changeTheme}>
<option value='darkLook'>Dark</option>
<option value='lightLook'>Light</option>
</select>
<br/><br/>
<AboutUsComponent theme={theme}/>
</div>
)
}

const AboutUsComponent=({theme})=>{
return(
<div className={[theme,lookAndFeel.aboutUs].join(" ")}>
<h3>Our Courses</h3>
Great Things take time to happen .<br/>
All you need to do is work hard .<br/>
</div>
)
}

export default App;