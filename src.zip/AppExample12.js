import React from 'react'
function Factorial(num)
{
var p=new Promise(function(resolve){
setTimeout(function(){
var i=1,j=1;
for(;j<=num;j++)
{
i=i*j;
}
resolve(i);
},4000);
});
return p;
}

const App=()=>{

const buttonClickHandler=()=>{
var prms=Factorial(5);
alert('Factorial is being produced somewhere else');
prms.then(function(factorial){
alert('Factorail of the number 5 is : '+factorial);
});
}

return(
<div>
<h1>Thinking Machines</h1>
<h3> Factorial calculator</h3>
<button type='button' onClick={buttonClickHandler}>Click Here</button>
</div>
)
}
export default App;