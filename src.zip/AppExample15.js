import React from 'react'

const App=()=>{

const [title,setTitle]=React.useState("Think Big");
const [something,setSomething]=React.useState("Just do it");

React.useEffect(()=>{
alert("Cool Fool");
},[]); //replace [] with [title] then [something] then [title,something]

const changeTitle=()=>{
setTitle("We Teach More Than We Promise To Teach");
}

const doSomething=()=>{
setSomething("Whatever");
}

return(
<div>
<h1>Thinking Machines</h1>
<TitleComponent title={title} abcd={something}/><br/><br/>
<button type='button' onClick={changeTitle}>Change Title</button><br/><br/>
<button type='button' onClick={doSomething}>Change Something</button>
</div>
)
}

const TitleComponent=({title,abcd})=>{
return(
<div>
{title}<br/><br/>
<h3>{abcd}</h3>
</div>
)
}
export default App;