import React from 'react'
import {makeStyles} from '@material-ui/core';
import Paper from '@material-ui/core/Paper';
import TableContainer from '@material-ui/core/TableContainer';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import TableCell from '@material-ui/core/TableCell';
import KeyboardArrowUpIcon from '@material-ui/icons/KeyboardArrowUp';
import KeyboardArrowDownIcon from '@material-ui/icons/KeyboardArrowDown';
import IconButton from '@material-ui/core/IconButton';
import Collapse from '@material-ui/core/Collapse';
import Box from '@material-ui/core/Box';

const myStyles=makeStyles((theme)=>{return(
{
mainContainer :{
paddingLeft:theme.spacing(4),
paddingRight:theme.spacing(4)
},
paper:
{
paddingRight:theme.spacing(4),
paddingLeft:theme.spacing(4),
paddingBottom:theme.spacing(4),
paddingTop: theme.spacing(4)
}
}
);});

const departments=[
{"name":"Physics","students":[
{"rollNumber":101,"name":"Sameer Joshi","city":"Ujjain"},
{"rollNumber":102,"name":"Noddy Barhman","city":"Indore"},
{"rollNumber":103,"name":"Shaner Habbib","city":"Bhopal"}
]},
{"name":"Chemistry","students":[
{"rollNumber":104,"name":"Umesh jundra","city":"Omar"},
{"rollNumber":105,"name":"Dard Mard","city":"Rai"},
{"rollNumber":106,"name":"Insan yusuf","city":"Junagard"},
]}
]
const DepartmentRow=(props)=>{
const [openState,setOpenState]=React.useState(false);
return(
<React.Fragment>
<TableRow>
<TableCell>
<IconButton onClick={()=>{setOpenState(!openState);}}>
{openState? <KeyboardArrowUpIcon/> : <KeyboardArrowDownIcon/>}
</IconButton>
</TableCell>
<TableCell>{props.serialNumber}</TableCell>
<TableCell>{props.departments.name}</TableCell>
</TableRow>
<TableCell colSpan={3}>
<Collapse in={openState}>
<Box margin={3}>
<Table>
<TableHead>
<TableCell>S.N0.</TableCell>
<TableCell>Roll no.</TableCell>
<TableCell>Name</TableCell>
<TableCell>City</TableCell>
</TableHead>
<TableBody>
{
props.departments.students.map((student,idx)=>{return(
<TableRow>
<TableCell>{idx+1}</TableCell>
<TableCell>{student.rollNumber}</TableCell>
<TableCell>{student.name}</TableCell>
<TableCell>{student.city}</TableCell>
</TableRow>
);})
}

</TableBody>
</Table>
</Box>
</Collapse>
</TableCell>
<TableRow>
</TableRow>
</React.Fragment>
);
}

const AppExample44=()=>{
const classes=myStyles();
return(
<div className={classes.mainContainer}>
<Paper className={classes.paper}>
<h1>Thinking Machines</h1>
<TableContainer>
<Table>
<TableHead>
<TableRow>
<TableCell/>
<TableCell>S.No.</TableCell>
<TableCell>Department</TableCell>
</TableRow>
</TableHead>
<TableBody>
{
departments.map((department,idx)=>{return(
<DepartmentRow serialNumber={idx+1} department={department} />
);})
}
</TableBody>
</Table>
</TableContainer>
</Paper>
</div>
);
}
export default AppExample44;