import React from 'react'
import {makeStyles} from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import TableHead from '@material-ui/core/TableHead';
import TableBody from '@material-ui/core/TableBody';
import TableRow from '@material-ui/core/TableRow';
import TableCell from '@material-ui/core/TableCell';
import TableSortLabel from '@material-ui/core/TableSortLabel';
import CircularProgress from '@material-ui/core/CircularProgress';

const myStyles=makeStyles((theme)=>{
return({
mainContainer:{flexGrow : 1},
content:{
padding: "10px",
textAling:"center"
},
mainHeading:{
fontSize:"24pt",
fontWeight:"bold",
color:"#2222ab"
},
})
});

const getStudents=()=>{
var promise=new Promise((resolve)=>{
var students=[
{"name":"Aditi","company":"HashedIn","package":"8LPA"},
{"name":"Suthy","company":"Intel","package":"15LPA"},
{"name":"Rutea","company":"Rizi","package":"12LPA"},
];
setTimeout(()=>{
resolve(students);
},1000);
});
return promise;
}

const studentComparator=(left,right,order)=>{
if(order=='asc')
{
return left.name.toLowerCase().localeCompare(right.name.toLowerCase());
}
if(order=='desc')
{
return right.name.toLowerCase().localeCompare(left.name.toLowerCase());
}
}

const sortStudentsByName=(students,order)=>{
students.sort((left,right)=>{return studentComparator(left,right,order);});

}

const AppExample41=()=>{
const styleClasses=myStyles();
const [students,setStudents]=React.useState([]);
const [showProgress,setShowProgress]=React.useState(true);
const [nameOrder,setNameOrder]=React.useState('asc');

React.useEffect(()=>{
getStudents().then((s)=>{
setShowProgress(false);
sortStudentsByName(s,"asc");
setStudents(s);
});
},[]);

const nameSortLabelClickHandler=()=>{
if(nameOrder=="asc")
{
setNameOrder("desc");
sortStudentsByName(students,"desc");
}
else
{
setNameOrder("asc");
sortStudentsByName(students,"asc");
}
}

return(
<div className={styleClasses.mainContainer}>
<div className={styleClasses.mainHeading}>Thinking Machines</div>
<div className={styleClasses.content}>
<Table>
<TableHead>
<TableRow>
<TableCell aling='right'>S.No.</TableCell>
<TableCell><TableSortLabel direction={nameOrder} onClick={nameSortLabelClickHandler}>Student</TableSortLabel></TableCell>
<TableCell>Company</TableCell>
<TableCell>Package</TableCell>
</TableRow>
</TableHead>
<TableBody>
{students.map((student,idx)=>{
return(
<TableRow>
<TableCell aling='right'>{idx+1}</TableCell>
<TableCell>{student.name}</TableCell>
<TableCell>{student.company}</TableCell>
<TableCell>{student.package}</TableCell>
</TableRow>
);
})}
</TableBody>
</Table><br/><br/>

<CircularProgress />
</div>
</div>
);
};
export default AppExample41;