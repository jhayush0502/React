//npm install -save react-router-dom                  -> module needed to be downloaded first

import React from 'react'
import {BrowserRouter,Route,Link} from 'react-router-dom';

const AppExample34=()=>{
return(
<BrowserRouter>
<Route exact path='/' component={HomeComponent} />
<Route exact path='/courses' component={CoursesComponent} />
<Route exact path='/contactUs' component={ContactComponent} />
</BrowserRouter>
)
}

const HomeComponent=()=>{
return(
<div>
<h1>Thinking Machines</h1>
<Link to='/courses'>Courses</Link><br/>
<Link to='/contactUs'>Contact Us</Link>
</div>
);
}

const CoursesComponent=()=>{
return(
<div>
<h1>Thinking Machines</h1>
<h3>Courses</h3>
<Link to='/'>Home</Link>
</div>
);
}

const ContactComponent=()=>{
return(
<div>
<h1>Thinking Machines</h1>
<h3>Contact Us</h3>
<Link to='/'>Home</Link>
</div>
);
}

export default AppExample34;