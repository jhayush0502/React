import React from 'react' ;
import {withStyles} from '@material-ui/core/styles';
import Paper from '@material-ui/core/Paper';
import Grid from '@material-ui/core/Grid';

const lookAndFeel=()=>{
return ({
mainContainer :{
margin : "10px",
border : "1px solid magenta",
flexGrow : 1,
padding :"10px"
},
paper :{padding : "5px",
color: "red"
}
})
}

const App=withStyles(lookAndFeel)(({classes})=>{
const x=6; //we can change this value to have various layouts(i.e here x=5 so ek line me 12/5=2 components aaenge)
return(
<div className={classes.mainContainer}>
<Grid container spacing={4}>
<Grid item xs="auto" sm="auto" md="auto">
<Paper className={classes.paper}>1</Paper>
</Grid>

<Grid item xs="auto" sm="auto" md="auto">
<Paper className={classes.paper}>2</Paper>
</Grid>
<Grid item xs="auto" sm="auto" md="auto">
<Paper className={classes.paper}>3</Paper>
</Grid>
<Grid item xs="auto" sm="auto" md="auto">
<Paper className={classes.paper}>4</Paper>
</Grid>
<Grid item xs="auto" sm="auto" md="auto">
<Paper className={classes.paper}>5</Paper>
</Grid>
<Grid item xs="auto" sm="auto" md="auto">
<Paper className={classes.paper}>6</Paper>
</Grid>
<Grid item xs="auto" sm="auto" md="auto">
<Paper className={classes.paper}>7</Paper>
</Grid>
<Grid item xs="auto" sm="auto" md="auto">
<Paper className={classes.paper}>8</Paper>
</Grid>
<Grid item xs="auto" sm="auto" md="auto">
<Paper className={classes.paper}>9</Paper>
</Grid>
<Grid item xs="auto" sm="auto" md="auto">
<Paper className={classes.paper}>10</Paper>
</Grid>
<Grid item xs="auto" sm="auto" md="auto">
<Paper className={classes.paper}>11</Paper>
</Grid>
<Grid item xs="auto" sm="auto" md="auto">
<Paper className={classes.paper}>12</Paper>
</Grid>
</Grid>
</div>
)
});
export default App;
