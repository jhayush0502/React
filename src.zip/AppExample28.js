const AppExample28=()=>{
const tooCool=()=>{
return function(n){
alert(n*n);
}
}

const doSomething=()=>{
const k=tooCool();
k(100);
tooCool()(10);
}
return(
<div>
<h1>Thinking Machines</h1>
<button type='button' onClick={doSomething}>Click Me</button>
</div>
)
}
export default AppExample28;