import React from 'react'
function Factorial(num)
{
var i,j;
for(i=1,j=1;j<=num;j++)
{
i=i*j;
}
return i;
}


const App=()=>{

const buttonClickHandler=()=>{
var factorial=Factorial(5);
alert('Factorial of 5 is : '+factorial);
}

return(
<div>
<h1>Thinking Machines</h1>
<button type='button' onClick={buttonClickHandler}>Click me</button>
</div>
)

}
export default App;