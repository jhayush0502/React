import React from 'react'

const getCompanies=()=>{
var promise=new Promise((resolve,reject)=>{
fetch("/companies").then((response)=>{
if(!response.ok) throw Error("OOPS, can't fetch data,try after some time");
return response.json();
}).then((companies)=>{
resolve(companies);
}).catch((error)=>{
reject(error.message);
});
});
return promise;
}

const PlacementsDashboard=()=>{

const [companies,setCompanies]=React.useState([]);
const [filter,setFilter]=React.useState({jobType:[],salaryType:[],companies:[]});


React.useEffect(()=>{
getCompanies().then((companies)=>{
setCompanies(companies);
},(error)=>{
alert(error);
});
},[]);

const applyFilter=(f)=>{
setFilter(f);
}

return(
<div>
<HeaderComponent year='2021' />
<div style={{display:'flex'}}>
<div style={{marginLeft: "20px",paddingRight: "10px",borderRight: "1px Solid #49b2cc",fontSize:"15pt"}}>
<div style={{width: "100%",backgroundColor:"#49b2cc",padding:"2px",textAling:"center",color:"#FFFFFF",fontWeight:"bold"}}>F I L T E R S</div>

<FilterComponent companies={companies} onChange={applyFilter} />
</div>

<div style={{flexGrow: 1,marginLeft: "20px"}}>
<PlacementsComponent filterBy={filter} />
</div>
</div>
</div>
)
}

const FilterComponent=({companies,onChange})=>{

return(
<div>
<JobTypeComponent />
<hr/>
<SalaryTypeComponent />
<hr/>
<CompaniesComponent companies={companies}/>
</div>
)
}

const HeaderComponent=({year})=>{
return(
<h1>Thinking Machines - Placement Records ({year})</h1>
)
}

const JobTypeComponent=()=>{
return(
<fieldset>
<legend>Salary Type</legend>
<input type='checkbox' value='F' style={{width: "20px",height:"20px"}}/>Full time<br/>
<input type='checkbox' value='I' style={{width:"20px",height:"20px"}}/>Internship<br/>
</fieldset>
)
}

const SalaryTypeComponent=()=>{
return(
<fieldset>
<legend>Salary Type</legend>
<input type='checkbox' value='M' style={{width: "20px",height:"20px"}}/>Monthly<br/>
<input type='checkbox' value='Y' style={{width: "20px",height:"20px"}}/>Yearly<br/>
</fieldset>
)
}

const CompaniesComponent=({companies})=>{
return(
<fieldset>
<legend>Companies</legend>
{
companies.map((company)=>{
return(
<span key={company.name}>
<input type='checkbox' value={company.name} style={{width: "20px",height:"20px"}}/> {company.name} ({company.studentsCount}) <br/>
</span>
)
})
}
<fieldset>
)
}

const PlacementsComponent=()=>{
return(
<h1>Students</h1>
)
}

export default PlacementsDashboard;