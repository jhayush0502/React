import React from 'react';

const App=()=>{
const titles=[
"Thinking Machines",
"Think Big",
"Be Consistent",
"Be Patient",
"Be Hardworking",
"Here you reach at your destination"
];
const [titleIndex,setTitleIndex]=React.useState(0);

const changeTitle=()=>{
if(titleIndex==titles.length-1) setTitleIndex(0);
else setTitleIndex(titleIndex+1);
}

return (
<div>
<h1 onClick={changeTitle}>{titles[titleIndex]}</h1>
Current Title from index : {titleIndex}
</div>
)
}

export default App;

