import React from 'react'
import lookAndFeel from 'styled-components'

const StylishContainer=lookAndFeel.div`
width : 500px;
height : 400px;
margin : 10px;
border : 2px solid green;
padding : 5px;
`;

const StylishHeading=lookAndFeel.h1`
background : green;
background : linear-gradient(to left,red,green);
color : purple;
font-weight : bold;
font-size : 30pt;
`;

const StylishAboutUs=lookAndFeel.div`
width : 400px;
height : 200px;
padding : 10px ;
margin : 10px;
background : ${(wrapper)=>{return wrapper.themeInAction.backgroundColor}};
color : ${(wrapper)=>{return wrapper.themeInAction.foregroundColor}};
border : ${wrapper => wrapper.themeInAction.borderType};
`;

const StylishModuleHeading=lookAndFeel.h3`
font-weight : bold;
font-size : 20pt;
`;

const darkTheme={
backgroundColor : "red",
foregroundColor : "white",
borderType : "1px solid red"
}

const LightTheme={
backgroundColor : "pink",
foregroundColor : "black",
borderType :"1px solid black"
}

const App=()=>{
const [theme,setTheme]=React.useState(darkTheme);
const [themeName,setThemeName]=React.useState("darkLook");

const updateTheme=(ev)=>{
setThemeName(ev.target.value);
if(ev.target.value=="darkLook") setTheme(darkTheme);
if(ev.target.value=="LightLook") setTheme(LightTheme);
}

return(
<StylishContainer>
<StylishHeading>Thinking Machines</StylishHeading>
Select theme&nbsp;&nbsp;
<select value={themeName} onChange={updateTheme}>
<option value='darkLook'>Dark</option>
<option value='LightLook'>Light</option>
</select>
<AboutUsComponent applyTheme={theme}/>
</StylishContainer>
)
}

const AboutUsComponent=({applyTheme})=>{
return(
<StylishAboutUs themeInAction={applyTheme}>
<StylishModuleHeading>About Us</StylishModuleHeading>
We Teach More Than we Promise to teach
</StylishAboutUs>
)
}

export default App;