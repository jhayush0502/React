import React from 'react'
const studentImages=require.context("../public/students");

var m="virat"
//first way-> without dynamisym
const rohit=studentImages("./hitman.png");
//second way -> with dynamisym 
const virat=studentImages(`./${m}.jpg`);

const App=()=>{
const r="RVD.jpg"; 
return(
<div>
<h1>Thinking Machines</h1>
<img src={rohit.default} />
<img src={virat.default} /><br/>
<img src={`${process.env.PUBLIC_URL}/students/${r}`}/>
</div>
)
}

export default App;