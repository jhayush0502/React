import React,{Component,useRef} from 'react'
function App()
{
const [aaa,bbb]=React.useState("God is Great");
const doSomething=()=>{
bbb("Ujjain is the city of gods");
}
return(
<div>
< h1 onClick={doSomething}>Thinking Machines</h1>
<Title slogan={aaa}/>
</div>
);
}

const Title=(props)=>{
return (
<div>
<h3>{props.slogan}</h3>
</div>
)
}
export default App;