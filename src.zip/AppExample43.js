import React from 'react';
import Paper from '@material-ui/core/Paper';
import {makeStyles} from '@material-ui/core';
import TableContainer from '@material-ui/core/TableContainer';
import Table from '@material-ui/core/Table';
import TableHead from '@material-ui/core/TableHead';
import TableBody from '@material-ui/core/TableBody';
import TableRow from '@material-ui/core/TableRow';
import TableCell from '@material-ui/core/TableCell';
import TablePagination from '@material-ui/core/TablePagination';
import Checkbox from '@material-ui/core/Checkbox';
const students=[
{"rollNumber":101,"name":"Lakhvir"},
{"rollNumber":102,"name":"Quaid"},
{"rollNumber":103,"name":"Trisha"},
{"rollNumber":104,"name":"Kajal"},
{"rollNumber":105,"name":"Faruk"},
{"rollNumber":106,"name":"Dhruv"},
{"rollNumber":107,"name":"Walt"},
{"rollNumber":108,"name":"Ritu"},
{"rollNumber":109,"name":"Ishan"},
{"rollNumber":110,"name":"Elvish"},
{"rollNumber":111,"name":"Sameer"},
{"rollNumber":112,"name":"Sanjeev"},
{"rollNumber":113,"name":"Puresh"},
{"rollNumber":114,"name":"Yash"},
{"rollNumber":115,"name":"Umesh"}
]
var myStyles=makeStyles((theme)=>{return{
mainContainer :{
color:"blue",
paddingLeft:theme.spacing(5),
paddingRight: theme.spacing(5)
},
dataContainer :{
height : "300px"
},
mainPaper:{
paddingLeft : theme.spacing(5),
paddingRight: theme.spacing(5),
paddingTop:theme.spacing(2),
paddingBottom: theme.spacing(2)
}
};});

const AppExample43=()=>{
const [pageSize,setPageSize]=React.useState(5);
const [pageNumber,setPageNumber]=React.useState(1);
const [selectedStudents,setSelectedStudents]=React.useState([]);
const [areAllSelected,setAreAllSelected]=React.useState(false);

const onPageSizeChanged=(ev)=>{
setPageSize(ev.target.value);
setPageNumber(1);
}

const onPageChanged=(ev,pg)=>{
setPageNumber(pg+1);
}

const isStudentSelected=(rollNumber)=>{
return selectedStudents.indexOf(rollNumber)!=-1;
}

const onSelectAllClicked=()=>{
var selections=[];
if(areAllSelected)
{
setAreAllSelected(false);
}
else
{
students.forEach((student)=>{
selections.push(student.rollNumber);
});
setAreAllSelected(true);
}
setSelectedStudents(selections);
}

const onTableRowClicked=(rollNumber)=>{
var selections=[];
var index=selectedStudents.indexOf(rollNumber);
if(index==-1)
{
selections=selections.concat(selectedStudents,rollNumber);
}
else
{
if(index==0) selections=selections.concat(selectedStudents.slice(1));
else if(index==selectedStudents.length-1) selections=selections.concat(selectedStudents.slice(0,selectedStudents.length-1));
else
{
selections=selections.concat(selectedStudents.slice(0,index),selectedStudents.slice(index+1));
}
}
setSelectedStudents(selections);
if(selections.length==0) setAreAllSelected(false);
if(selections.length==students.length) setAreAllSelected(true);
}
var classes=myStyles();
return(<div className={classes.mainContainer}>
<Paper className={classes.mainPaper}>
<h1>Thinking Machines</h1>
Number of students selected : {selectedStudents.length}
<TableContainer className={classes.dataContainer}>
<Table stickyHeader>
<TableHead>
<TableRow>
<TableCell>
<Checkbox
indeterminate={selectedStudents.length>0 && selectedStudents.length<students.length}
checked={areAllSelected}
onClick={onSelectAllClicked}
/></TableCell>
<TableCell>S.no</TableCell>
<TableCell>Roll Number</TableCell>
<TableCell>Name</TableCell>
</TableRow>
</TableHead>
<TableBody>
{
students.slice((pageNumber-1)*pageSize,(pageNumber-1)*pageSize+pageSize).map((student,idx)=>{
const selectionState=isStudentSelected(student.rollNumber);
return(
<TableRow key={student.rollNumber} hover onClick={()=>{onTableRowClicked(student.rollNumber);}}>
<TableCell><Checkbox checked={selectionState}/></TableCell>
<TableCell>{(pageNumber-1)*pageSize+(idx+1)}</TableCell>
<TableCell>{student.rollNumber}</TableCell>
<TableCell>{student.name}</TableCell>
</TableRow>
);
})
}

<TableRow rowSpan={3}>
<TableCell colspan={2}>Thinking Machines</TableCell>
<TableCell>Sub Total</TableCell>
<TableCell>11100</TableCell>
</TableRow>
<TableRow>
<TableCell colspan={2}>Basant Vihar</TableCell>
<TableCell>Tax</TableCell>
<TableCell>110</TableCell>
</TableRow>
<TableRow>
<TableCell colspan={2}>Ujjain</TableCell>
<TableCell>Total</TableCell>
<TableCell>11210</TableCell>
</TableRow>
</TableBody>
</Table>
</TableContainer>
<TablePagination
component="div"
rowsPerPageOptions={[5,10,15,20,25]}
count={students.lenght}
rowsPerPage={pageSize}
page={pageNumber-1}
onChangePage={onPageChanged}
onChangeRowsPerPage={onPageSizeChanged}
/>
</Paper>
</div>
)
}
export default AppExample43;