import React from 'react'
function Factorial(num,AddOfAFunction)
{
setTimeout(function(){
var i=1,j=1;
for(;j<=num;j++)
{
i=i*j;
}
AddOfAFunction(i);
},4000);
}

const App=()=>{

const buttonClickHandler=()=>{
var factorial=Factorial(6,function(factorial){
alert('factorial of 6 is '+factorial);
});
alert('Factorial is being calculated');
}
return(
<div>
<h1>Thinking Machines</h1>
<h3> Factorial calculator</h3>
<button type='button' onClick={buttonClickHandler}>Click Here</button>
</div>
)
}
export default App;