import React from 'react' ;
import {withStyles} from '@material-ui/core/styles';
import Paper from '@material-ui/core/Paper';
import Grid from '@material-ui/core/Grid';
import Chip from '@material-ui/core/Chip';

const lookAndFeel=()=>{
return ({
mainContainer :{
margin : "10px",
border : "1px solid magenta",
flexGrow : 1,
padding :"10px"
},
paper :{padding : "5px",
color: "red"
}
})
}

const App=withStyles(lookAndFeel)(({classes,justify})=>{
return(
<div className={classes.mainContainer}>
<Grid container spacing={4}>

<Grid item xs={12} sm={6} md={3}>
<Paper className={classes.paper}>
<Grid container justify={justify}>
<Grid item><Chip label='1'/></Grid>
<Grid item><Chip label='2'/></Grid>
<Grid item><Chip label='3'/></Grid>
</Grid>
</Paper>
</Grid>

<Grid item xs={12} sm={6} md={3}>
<Paper className={classes.paper}>
<Grid container justify="center">
<Grid item><Chip label='4'/></Grid>
<Grid item><Chip label='5'/></Grid>
<Grid item><Chip label='6'/></Grid>
</Grid>
</Paper>
</Grid>

<Grid item xs={12} sm={6} md={3}>
<Paper className={classes.paper}>
<Grid container justify="space-around">
<Grid item><Chip label='7'/></Grid>
<Grid item><Chip label='8'/></Grid>
<Grid item><Chip label='9'/></Grid>
</Grid>
</Paper>
</Grid>

<Grid item xs={12} sm={6} md={3}>
<Paper className={classes.paper}>
<Grid container justify="space-evenly">
<Grid item><Chip label='10'/></Grid>
<Grid item><Chip label='A'/></Grid>
<Grid item><Chip label='11'/></Grid>
</Grid>
</Paper>
</Grid>


<Grid item xs={12} sm={6} md={3}>
<Paper className={classes.paper}>
<Grid container justify="flex-start">
<Grid item><Chip label='12'/></Grid>
<Grid item><Chip label='B'/></Grid>
<Grid item><Chip label='13'/></Grid>
</Grid>
</Paper>
</Grid>


<Grid item xs={12} sm={6} md={3}>
<Paper className={classes.paper}>
<Grid container justify="flex-end">
<Grid item><Chip label='14'/></Grid>
<Grid item><Chip label='C'/></Grid>
<Grid item><Chip label='15'/></Grid>
</Grid>
</Paper>
</Grid>


</Grid>
</div>
)
});
export default App;
