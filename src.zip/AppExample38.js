import React from 'react';
import {withStyles} from '@material-ui/core';
import {BrowserRouter,Route} from 'react-router-dom';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import IconButton from '@material-ui/core/IconButton';
import MenuIcon from '@material-ui/core/Menu';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import Drawer from '@material-ui/core/Drawer';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemText from '@material-ui/core/ListItemText';
import Link from '@material-ui/core/Link';
import ListSubHeader from '@material-ui/core/ListSubHeader';  

const myStyles=(theme)=>{return({
mainContainer :{
flexGrow : 1
},
appBarSpacer: theme.mixins.toolbar,
content:{
padding : "10px"
},
appBar:{
zIndex : theme.zIndex.drawer+1000
}
})
}

const AppExample38=(props)=>{
const [tabIndex,setTabIndex]=React.useState(0);
const [routeComponent,setRouteComponent]=React.useState(HomeComponent);
const [showDrawer,setShowDrawer]=React.useState(false);

const onTabChange=(ev,val)=>{
setShowDrawer(false);
if(val==tabIndex) return;
setTabIndex(val);
if(val==0) setRouteComponent(HomeComponent);
else if(val==1) setRouteComponent(CoursesComponent);
else if(val==2) setRouteComponent(ContactComponent);
}

const openDrawer=()=>{
setShowDrawer(true);
}

return(
<BrowserRouter>
<div className={props.classes.mainContainer}>
<AppBar className={props.classes.appBar}>
<Toolbar>
<IconButton color='inherit' onClick={openDrawer}>
<MenuIcon/>
</IconButton>
<Tabs value={tabIndex} onChange={onTabChange}>
<Tab label='Home' />
<Tab label='Courses'/>
<Tab label='Contact Us'/>
</Tabs>
</Toolbar>
</AppBar>
<Drawer varient='varient' open={showDrawer} onClick={()=>{ setShowDrawer(!showDrawer);}}>
<Toolbar/>
<List>
<ListItem component={Link} onClick={()=>{onTabChange(null,0);
setShowDrawer(!showDrawer);}}>
<ListItemText>Home</ListItemText>
</ListItem>
<ListSubHeader>Some Sub Heading </ListSubHeader>
<ListItem component={Link} onClick={()=>{onTabChange(null,1);
setShowDrawer(!showDrawer);}}>
<ListItemText>Courses</ListItemText>
</ListItem>
<ListItem component={Link} onClick={()=>{onTabChange(null,2);
setShowDrawer(!showDrawer);}}>
<ListItemText>Contact Us</ListItemText>
</ListItem>
</List>
</Drawer>
<div className={props.classes.appBarSpacer} />
<div className={props.classes.content}>
<Route path='/' exact component={routeComponent} />
</div>
</div>
</BrowserRouter>
)}

const HomeComponent=withStyles(myStyles)(({classes})=>{
return(
<div>
<h1>Home</h1>
<h3>Welcome</h3>
</div>
)
});

const CoursesComponent=withStyles(myStyles)(({classes})=>{
return(
<div>
<h1>Courses</h1>
<h3>List of Courses</h3>
</div>
)
});

const ContactComponent=withStyles(myStyles)(({classes})=>{
return(
<div>
<h1>Contact us</h1>
<h3>9522226242</h3>
</div>
)
});

export default withStyles(myStyles)(AppExample38);