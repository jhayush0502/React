import React,{Component,useRef} from 'react'

function App()
{
const slogan="We Teach More than we promise to teach";
const kk=useRef();
const changeSlogan=()=>{
alert('Change the slogan');
kk.current.updateSlogan("Think Big  20-30 Lpa");
}
return(
<div>
<h1>Thinking Machines</h1>
<Title slogan={slogan} onClicked={changeSlogan} ref={kk}/>
</div>
);
}

class Title extends React.Component
{
constructor(props)
{
super(props);
this.state={
"slogan":props.slogan
}
this.onClicked=props.onClicked;
}
updateSlogan(slogan)
{
this.setState({
"slogan":slogan
});
}
clickHandler=()=>{
this.onClicked();
}
render()
{
return(
<h3 onClick={this.clickHandler}>{this.state.slogan}</h3>
)}
}
export default App;