var left="Bobby"
var right="karan"
//for ascending sort
console.log(left.toLowerCase().localeCompare(right.toLowerCase()))
//for decending sort
console.log(right.toLowerCase().localeCompare(left.toLowerCase()))