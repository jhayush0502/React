import React from 'react'

const getStudents=()=>{
var promise=new Promise((resolve)=>{
fetch("/placements").then((response)=>{
return response.json();
}).then((students)=>{
resolve(students);
});
});
return promise;
}

const AppExample16=()=>{
const [activeMode,setActiveMode]=React.useState("view");
const [students,setStudents]=React.useState([]);

React.useEffect(()=>{
getStudents().then((s)=>{
setStudents(s);
});
},[]);

const onToolBarItemSelected=function(item){
if(item==="add") setActiveMode("add");
if(item==="cancel") setActiveMode("view");
}

const setViewMode=()=>{
setActiveMode("view");
}

return(
<div>
<h1>Thinking Machines</h1>
<ToolBar mode={activeMode} onItemSelected={onToolBarItemSelected}/>
{ activeMode==="view" && <StudentViewComponent students={students}/> }
{ activeMode==="add" && <StudentAddComponent /> onStudentAdded={onStudentAdded} onDismiss={setViewMode}/> }
</div>
)
}

const ToolBar=({mode,onItemSelected})=>{
const takeAction=(ev)=>{

onItemSelected(ev.currentTarget.getAttribute("target_action"));
}

return(
<div>
<hr/>
{ mode==="view" && <button type='button' onClick={takeAction} target_action="add">Add</button>}
{ mode==="add" && <button type='button' onClick={takeAction} target_action="cancel">cancel</button>}
)
&nbsp; ..... More rock more in project
<hr/>
</div>
)
}
const StudentViewComponent=()=>{
return(
<div>
<h1>Placements</h1>
<hr/>
{
student.map((student)=>{
return(
<div key={student.id}>
Name : {student.name}<br/>
Company : {student.company} ({student.placementType})<br/>
Package : {student.salary}
<hr/>
)
})
}
</div>
)
}

const StudentAddComponent=({onStudentAdded,onDismiss})=>{

const [displayWhat,setDisplayWhat]=React.useState("formSection");

const [id,setId]=React.useState(0);
const [idError,setIdError]=React.useState("");

const [name,setName]=React.useState("");
const [nameError,setNameError]=React.useState("");

const [company,setCompany]=React.useState("");
const [companyError,setCompanyError]=React.useState("");

const [salary,setSalary]=React.useState(0);
const [salaryError,setSalaryError]=React.useState("");

const [salaryType,setSalaryType]=React.useState("Y");

const [fullTimeChecked,setFullTimeChecked]=React.useState("checked");
const [internshipChecked,setInternshipChecked]=React.useState("");
const [placementType,setPlacementType]=React.useState("F");

const [formError,setFormError]=React.useState("");

const idChanged=(ev)=>{
setId(ev.target.value);
}

const nameChanged=(ev)=>{
setCompany(ev.target.value.trim());
}

const salaryChanged=(ev)=>{
setSalary(ev.target.value);
}

const salaryTypeChanged=(ev)=>{
setSalaryType(ev.target.value);
}

const placementTypeChanged=(ev)=>{
if(ev.target.value=="F" && ev.target.checked)
{
setPlacementType("F");
setInternshipChecked("");
setFullTimeChecked("checked");
}

if(ev.target.value=="I" && ev.target.checked)
{
setPlacementType("I");
setInternshipChecked("checked");
setFullTimeChecked("");
}
}
const clearAllErrors=()=>{
setIdError("");
setNameError("");
setCompanyError("");
setSalaryError("");
}

const clearForm=()=>{
setId(0);
setName("");
setPlacementType("F");
setFullTimeChecked("");
setCompany("");
setSalary(0);
setSalaryType("Y");
}

const yesHandler=()=>{
setDisplayWhat("formSection");
}
const noHandler=()=>{
onDismiss();
}

const addClickedHandler=()=>{
clearAllErrors();
var hasErrors=false;
//alert(id+","+name+","+company+","+salary+","+salaryType+","+placementType);
if(id=="" || id<=0)
{
 setIdError(" * ");
hasErrors=true;
}
if(name="") 
{
setNameError(" * ");
hasErrors=true;
}
if(company="") 
{
setCompanyError(" * ");
hasErrors=true;
}
if(salary=="" || salary<=0)
{
 setSalaryError(" * ");
hasErrors=true;
}
if(hasErrors==true) return;

var student={
"id" : id,
"name" : name,
"placementType": placementType,
"company": company,
"salary" : salary,
"salaryType" : salaryType
};
setDisplayWhat("processingSection");

addPlacement(student).then((responseJSON)=>{
if(responseJSON.success==true)
{
onStudentAdded(student);
clearForm();
setDisplayWhat("addMoreSection");
}
else
{
setFormError(responseJSON.error);
setDisplayWhat("formSection");
}
});
}

if(displayWhat==="addMoreSection") return(
<div>
Add More ?<br/>
<button type='button' onClick={yesHandler}>Yes</button> &nbsp;&nbsp;&nbsp;
<button type='button' onClick={noHandler}>No</button>
</div>
)

if(displayWhat==="processingSection") return (
<div>
<img src={progress} />
</div>
)

if(displayWhat==="formSection") return (
<div>
<h1>Add Placement entry</h1>
<div style={{color: 'red'}}>{formError}</div>
<label htmlFor='id'>Id.</label>
)

return(
<div>
<h1>Add a placement Entry</h1>

<label htmlFor='id'>Id</label>
<input type='number' id='id' value={id} onChange={idChanged}>
<span style={{color: 'red'}}>{idError}</span>
<br/>
<label htmlFor='name'>Name</label>
<input type='text' id='name' value={name} onChange={nameChanged} />
<span style={{color: 'red'}}>{nameError}</span>
<br/>
PlacementType
<input type='radio' id='fullTime' name='placementType' checked={fullTimeChecked} value='F' onChange={placementTypeChanged}/>Full Time &nbsp;&nbsp;&nbsp;
<input type='radio' id='internship' name='placementType' checked={internshipChecked} value='I' onChange={placementTypeChanged} />
Internship
<br/>

<label htmlFor='salary'>Salary</label>
<input type='number' id='salary' value={salary} onChange={salaryChanged}/>
<select id='salaryType' onChange={salaryTypeChanged}>
<option value='Y'>per annum</option>
<option value='M'>per month</option>
</select>
<span style={{color: 'red'}}>{salaryError}</span>
<br/>
<button type='button' onClick={addClickedHandler}>Add</button>
</div>
)
}
export default AppExample16 ;
