import React from 'react'

const App=()=>{
const [placementCounter,setPlacementCounter]=React.useState(0);
const doSomething=()=>{
alert("10==10"+","+(10==10));
alert("true==true"+","+(true==true));
alert("{}=={}"+","+({}=={}));
alert("function==function"+","+(function(){}==function(){}));
alert("()=>{}==()=>{}"+","+((()=>{})==(()=>{})));
}
const incrementPlacementCounter=()=>{
setPlacementCounter(placementCounter+1);
}
return(
<div>
<h1>Thinking Machines</h1>
<button onClick={incrementPlacementCounter} type='Button'>++</button>
<br/>
<button onClick={doSomething} type='Button'>Equality Evaluator</button>
<br/>
<NoticeBoard count={placementCounter} />
</div>
)
}

var oldData=null;
const NoticeBoard=({count})=>{

const data=React.useMemo(()=>{return {"city":"Ujjain","state":"M.P"}},[]);
//alert(oldData==data)
oldData=data;

return(
<div>
<h2>Notice Board</h2>
<h3>Number of Placements : {count} </h3>
</div>
)
}
export default App;