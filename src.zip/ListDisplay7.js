import React from 'react';

const students=[
{"id":101,"name":"Prakruti jain","type":"Full time","company":"Grow","package":"20 LPA"},
{"id":102,"name":"Shreyash sharma","type":"Full time","company":"Amazon","package":"18 LPA"},
{"id":103,"name":"Siddhant Johari","type":"Full time","company":"Accolite","package":"10 LPA"},
{"id":104,"name":"Yash Govindani","type":"Internship","company":"InvesTrack","package":"15000 per month"},
{"id":105,"name":"Aman sharma","type":"Internship","company":"Iprep","package":"21500 per month "}
]; 

const App=()=>{

const [title]=React.useState("Thinking Machines");
const [year]=React.useState(2021);

return (
<div>
<TitleComponent title={title} placementYear={year} />
<ToolBarComponent />
<StudentsListComponent students={students} />
</div>
)
}

const ToolBarComponent=()=>{
return(
<div>
<hr/>
<button type='button'> + </button>
<hr/>
</div>
)
}

const TitleComponent=({title,placementYear})=>{
return(
<h1>{title} - Placements ({placementYear})</h1>
)
}

const StudentsListComponent=({students})=>{
return (
<div>
{
students.map((student)=>{
return(
<StudentComponent key={student.id} student={student} />
)
})
}
</div>
)
}

const StudentComponent=({student})=>{
return (
<div>
<span> Name : {student.name}</span><br/>
<span> Company : {student.company} </span><br/>
<span> Placement type :{student.type}</span> &nbsp;&nbsp;&nbsp;&nbsp;
<span> Salary : {student.package} </span><br/>
<span> Year of Passing : {student.passingYear} </span>
<hr/>
</div>
)
}

export default App;