import React,{Component,useRef} from 'react'

const App=()=>{
const [childText,setChildText]=React.useState("");
const justDoit=(ev)=>{
setChildText(ev.currentTarget.value);
}

return(
<div>
<h1>Thinking Machines</h1>
<SomeComponent tellParent={justDoit} text={childText}/>
</div>
) 
}
const SomeComponent=(props)=>{
const doSomething=(ev)=>{
props.tellParent(ev);
}

return (
<div>
Something<input type='text' onChange={doSomething}></input>
<br></br>
Child is saying : <b>{props.text}</b>
</div>
)
}
export default App;