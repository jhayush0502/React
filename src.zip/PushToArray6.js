import React from 'react';

const titles=[
"Thinking Machines",
"Think Big",
"Be Consistent",
"Be Patient",
"Be Hardworking",
"Here you reach at your destination"
];

const App=()=>{

const [titleIndex,setTitleIndex]=React.useState(0);

const changeTitle=()=>{
if(titleIndex==titles.length-1) setTitleIndex(0);
else setTitleIndex(titleIndex+1);
}

const doSomething=()=>{
alert(titles.length);
titles.push("Programming is cool");
alert(titles.length);
setTitleIndex(0);
}

return (
<div>
<h1 onClick={changeTitle}>{titles[titleIndex]}</h1>
<h3 onClick={doSomething}>Current Title from index : {titleIndex}</h3>
</div>
)
}

export default App;

