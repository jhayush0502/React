import React from 'react';

const slogans=["Think Big","We Teach more than we promise to teach","Learn One : Implement Any"];

const App=()=>{

const [selectedSloganIndex,setSelectedSloganIndex]=React.useState(0);

/*const updateSlogan=()=>{
if(selectedSloganIndex==slogans.length-1)
{
setSelectedSloganIndex(0);
}
else
{
setSelectedSloganIndex(selectedSloganIndex+1);
}
}*/

const updateSlogan=()=>{
setSelectedSloganIndex((currentIndex)=>{
if(currentIndex==slogans.length-1) return 0;
else return currentIndex+1;
});
}

return(
<div>
<h1>Thinking Machines</h1>
<h3>{slogans[selectedSloganIndex]}</h3>
<button type='button' onClick={updateSlogan}>Update Slogan</button>
</div>
)
}
export default App;