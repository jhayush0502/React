var students=[
{"name":"Bobby","company":"HashedIn","package":"9LPA"},
{"name":"Inay","company":"HashedIn","package":"11LPA"},
{"name":"Ujjwal","company":"HashedIn","package":"6LPA"},
{"name":"Guraj","company":"HashedIn","package":"5LPA"},
{"name":"Ishita","company":"HashedIn","package":"8LPA"},
{"name":"Omkar","company":"HashedIn","package":"4LPA"},
{"name":"Tushar","company":"HashedIn","package":"10LPA"}
];
//students.sort((left,right)=>{return left.name.toLowerCase().localeCompare(right.name.toLowerCase())});
students.sort((left,right)=>{return right.name.toLowerCase().localeCompare(left.name.toLowerCase())});
var i;
for(i=0;i<students.length;i++)
{
console.log(students[i].name+","+students[i].package);
}

