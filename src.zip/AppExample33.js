import React from 'react';
import {withStyles} from '@material-ui/core';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import IconButton from '@material-ui/core/iconButton';
import MenuIcon from '@material-ui/core/Menu';
import Menu from '@material-ui/core/Menu';
import MenuItem from '@material-ui/core/MenuItem';

const myStyles=()=>{return ({
mainContainer :{
flexGrow : 1,
color : 'blue'
},
contentSection :{
marginTop : "80px"
}
})}

const App=({classes})=>{
const [anchorForMenu,setAnchorForMenu]=React.useState(null);

const appBarMenuIconClickHandler=(ev)=>{
setAnchorForMenu(ev.currentTarget);
}

const appBarMenuCloseHandler=()=>{
setAnchorForMenu(null);
}

return(
<div className={classes.mainContainer}>
<AppBar>
<Toolbar>
<IconButton color='white' onClick={appBarMenuIconClickHandler}>
<MenuIcon/>
</IconButton>
<Menu  anchorEl={anchorForMenu}  open={Boolean(anchorForMenu)}  onClose={appBarMenuCloseHandler} >
<MenuItem>Option 1</MenuItem>
<MenuItem>Option 2</MenuItem>
<MenuItem>Option 3</MenuItem>
<MenuItem>Option 4</MenuItem>
</Menu>
</Toolbar>
</AppBar>
<div className={classes.contentSection}>
Menu Testing
</div>
</div>
)
}
export default withStyles(myStyles)(App);