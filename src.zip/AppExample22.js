import React from 'react';
import "./AppExample22.css"
const App=()=>{
const [theme,setTheme]=React.useState("darkLook");

const changeTheme=(ev)=>{
setTheme(ev.target.value);
}

return(
<div className="mainContainer">
<h1>Thinking Machines</h1>
Select theme &nbsp;&nbsp;
<select value={theme} onChange={changeTheme}>
<option value='darkLook'>Dark</option>
<option value='lightLook'>Light</option>
</select>
<br/><br/>
<AboutUsComponent theme={theme}/>
</div>
)
}

const AboutUsComponent=({theme})=>{
return(
<div className={[theme,"aboutUs"].join(" ")}>
<h3>Our courses</h3>
Great Things take time to happen .<br/>
All you need to do is work hard .<br/>
</div>
)
}

export default App;