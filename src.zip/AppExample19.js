import React from 'react';
import ProcessingImage from './progress.gif'

const getPlacements=()=>{
var promise=new Promise((resolve,reject)=>{
fetch("Placements").then((response)=>{
//alert(response.ok);
if(!response.ok)
{
throw Error("Unable to fetch data,try after some time");
}
return response.json();
}).then((students)=>{
resolve(students);
}).catch((error)=>{
reject(error.message);
});
});
return promise;
}

var ViewStates={
loading:1,
loaded:2,
loadingError:3
};
object.freeze(ViewStates);//by this we restricted to make changes in 'ViewStates'  , as in other technologies there is a support for enums, so here we can evoke such facility through these step. 

const App=()=>{

const studentsStateReducer=(state,action)=>{
var ss={...state,viewState:action.viewState};
if(action.viewState==ViewState.loaded)
{
ss.students=action.students;
}
if(action.viewState==ViewStates.loadingError)
{
ss.error=action.error;
}
else
{
if(ss.error) delete ss.error;
}
return ss;
}

const [studentState,reduceStudentState]=React.useReducer(studentStateReducer,{"students":[],"viewState":ViewStates.loading});

React.useEffect(()=>{
getPlacements().then((students)=>{
reducerStudentsState({"students":students,"viewState":ViewStates.loaded});
//alert(students.length);
},(error)=>{
reduceStudentsState({"viewState":ViewStates.loadingError,"error":error});
//alert(error);
});
},[]);


return (
<div>
<h1>Thinking Machines</h1>
{studentState.viewState==ViewStates.loaded && <PlacementViewComponent students={studentState.students}/>}
{studentState.viewState==ViewStates.loading && <ProcessingViewComponent />}
{studentState.viewState==ViewStates.loadingError && <ErrorViewComponent error={studentState.error}/>}
</div>
)
}

const PlacementViewComponent=(students)=>{
return(
<div>
<ul>
{students.map((student)=>{
return(<li key={student.id}>{student.name}</li>
})}
</ul>
</div>
)
}

const ProcessingViewComponent=()=>{
return(
<div>
<img src={ProcessingImage} width='20%' height='20%' />
</div>
)
}

const ErrorViewComponent=({error})=>{
return(
<div>
<h3 style={{color:'red'}}>{error}</h3>
</div>
)
}

export default App;