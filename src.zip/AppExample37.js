import React from 'react';
import {withStyles} from '@material-ui/core';
import Typography from '@material-ui/core/Typography';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import Grid from '@material-ui/core/Grid';
import Button from '@material-ui/core/Button';
import Drawer from '@material-ui/core/Drawer';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemText from '@material-ui/core/ListItemText';
import Divider from '@material-ui/core/Divider';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import AddBox from '@material-ui/icons/AddBox';

const myStyles=(theme)=>{ return({
mainContainer :{flexGrow: 1},
appBarSpacer : theme.mixins.toolbar,
content :{color:"#2929aa"},
appBar : {
zIndex : theme.zIndex.drawer+1000
}
})}

const App=(props)=>{
////at place of 'persistent' -> 'permanent','temperory','varient'
const[showDrawer,setShowDrawer]=React.useState(false);
const openDrawer=()=>{
setShowDrawer(true);
}
const closeDrawer=()=>{
setShowDrawer(false);
}
return(
<div className={props.classes.mainContainer}>
<AppBar position='fixed' className={props.classes.appBar}>
<Toolbar>
<Typography>Thinking Machines</Typography>
</Toolbar>
</AppBar>
<div className={props.classes.appBarSpacer} />
<div className={props.classes.content}>
<Grid container justify='space-between'>
<Grid item>
<Drawer
open={showDrawer}
variant="persistent"
onClose={closeDrawer}
>
<Toolbar />
<List>
<ListItem button onClick={closeDrawer}>
<ListItemText>Option 1</ListItemText>
</ListItem>
<ListItem button onClick={closeDrawer}>
<ListItemText>Option 1</ListItemText>
</ListItem>
<ListItem button onClick={closeDrawer}>
<ListItemText>Option 2</ListItemText>
</ListItem>
<ListItem button onClick={closeDrawer}>
<ListItemText>Option 3</ListItemText>
</ListItem>
<ListItem button onClick={closeDrawer}>
<ListItemText>Option 4</ListItemText>
</ListItem>
</List>
</Drawer>
</Grid>
<Grid item>
{showDrawer==true && <Button onClick={closeDrawer}>Close Drawer</Button>}
{showDrawer==false && <Button onClick={openDrawer}>Open Drawer</Button>}
</Grid>
</Grid>
</div>
</div>
);
}
export default withStyles(myStyles)(App);