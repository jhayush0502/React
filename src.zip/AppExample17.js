import React from 'react'

const App=()=>{

/* (Phase-1)
const arrayReducer=()=>{
var x=[10,20,30,40,50];
x.reduce((a,b,c,d,e)=>{
alert(a);
alert(b);
alert(c);
alert(d);
alert(e);
});
} //Explaination in copy
*/

/*(Phase-2)
const arrayReducer=()=>{
var x=[10,20,30];
var j=x.reduce((a,b,c,d)=>{
alert(a);
alert(b);
alert(c);
alert(d);
return a+b;
},0);
alert("Total is : "+j);
}
*/


/*(Pure function)
//reducer1 is a pure function
const reducer1=(value,action)=>{
if(action=="UP") return value+1;
if(action=="DOWN") return value-1;
return value;
}

//reducer2 is not a pure function(here we are making changes in object itself(thus violating 2nd characteristic of pure function))
const reducer2=(obj,action)=>{
if(action=="UP") obj.value++;
if(action=="DOWN") obj.value--;
return obj;
}

//reducer3 is a pure function
const reducer3=(obj,action)=>{
var m={
"value":obj.value
}
if(action=="UP") m.value++;
if(action=="DOWN") m.value--;
return m;
}

const doSomething=()=>{
var v=10;
alert(reducer1(v,"UP"));
alert(reducer1(v,"DOWN"));
alert(v);

var k={"value":100}
alert(reducer2(k,"UP").value);
alert(k.value);
alert(reducer2(k,"DOWN").value);
alert(k.value);

var r={"value":250}
alert(reducer3(r,"UP").value);
alert(r.value);
alert(reducer3(r,"DOWN").value);
alert(r.value);
}
*/

/* (Spread operator)
const add=(e,f,g,h)=>{
return e+f+g+h;
}

const doSomething=()=>
{
var x=[10,20,30,40];
alert(add(x[0],x[1],x[2],x[3]));
alert(add(...x));
var a,b,c,d;
[a,b,c,d]=[...x];
alert(a);
alert(b);
alert(c);
alert(d);
}
*/

const reduceIt=(obj,action)=>{
if(action=="ADD")
{
return {...obj,"result":obj.firstNumber+obj.secondNumber};
}
if(action=="SUBTRACT")
{
return {...obj,"result":obj.firstNumber-obj.secondNumber};
}
return obj;
}
const doSomething=()=>{
var dataObject={
"firstNumber": 10,
"secondNumber":20,
"result":0
}
alert(reduceIt(dataObject,"ADD").result);
alert(dataObject.result);
alert(reduceIt(dataObject,"SUBTRACT").result);
alert(dataObject.result);
}

return(
<div>
<h1>Thinking Machines</h1>
<button onClick={doSomething}>Spread Operator</button>
</div>
)
}
export default App;